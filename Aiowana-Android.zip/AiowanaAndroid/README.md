# Aiowana — Android

A from-scratch native Android companion to the Aiowana desktop assistant.
Different tech stack on purpose (Kotlin/Android Studio, not PyQt6/Gemini
Live) — see the chat for why the desktop app can't be ported file-by-file.

## What's actually here (Phase 1 — core loop)

- **Local face recognition**, not system FaceID/BiometricPrompt. CameraX
  captures frames → Google ML Kit Face Detection (on-device, free) finds a
  face → a MobileFaceNet TFLite model (on-device, free) turns it into a
  vector → compared against names you enroll, entirely on this phone.
  System BiometricPrompt was deliberately **not** used here: it only tells
  an app "yes/no, the owner unlocked," never *which* of several people it
  saw — so it can't do "greet whoever's in frame by name."
- **Voice**, via Android's built-in `SpeechRecognizer` (speech→text,
  on-device where the phone/Android version supports it) and
  `TextToSpeech` (text→speech, fully on-device). Both free, no API key.
- **The "brain"**, via OmniRoute — a free, open-source, OpenAI-compatible AI
  gateway (github.com/diegosouzapw/OmniRoute) routing to free-tier models
  like Hermes, replacing the paid Gemini Live call the desktop app uses.
- **Adaptive greeting**: when a recognised face changes, the app greets
  that person by name and personalises the system prompt sent to OmniRoute
  with their name.

## What's NOT here yet (Phase 2 — say the word and I'll build it)

- PPT / website generation from an uploaded file. Same OmniRoute call
  underneath, different prompt + a slide/HTML builder — kept separate so
  Phase 1 is demoable on its own first.
- "Adaptive UI" beyond the greeting text (e.g. per-person theme/layout) —
  easy to add once you tell me what should actually change per person.

## One-time setup

You have three ways to build this. Pick based on how much local disk space
you're willing to spend:

### Option A — build in the cloud, ~zero local space (recommended if space is tight)

A GitHub Actions workflow is already included at `.github/workflows/build.yml`
— it compiles the APK on GitHub's servers, nothing installs on your PC but
a browser (and `git`, if you don't want to use the web upload instead).

1. Create a free GitHub account if you don't have one.
2. Create a new repository, then get this project's files into it — either
   `git init && git add . && git commit -m init && git remote add origin <your repo URL> && git push`,
   or just drag the unzipped `AiowanaAndroid` folder onto the repo's
   "Add file → Upload files" page in a browser (works for nested folders
   in modern GitHub).
3. Add the `mobilefacenet.tflite` file (see step below) to
   `app/src/main/assets/` *before* pushing, so it's included in the build.
4. Open the repo's **Actions** tab — the workflow runs automatically on
   push (or click "Run workflow" to trigger it manually).
5. When it finishes (a few minutes), click into the run → download the
   `aiowana-debug-apk` artifact → unzip it to get `app-debug.apk`.
6. Get that APK onto your phone any way you like (email to yourself,
   Google Drive, USB cable) and tap it to install. Android will ask you to
   allow "install from this source" the first time — allow it.
7. To rebuild after any code change, push again and repeat steps 4-6.

### Option B — command-line SDK only, no Studio app (~2-3GB instead of ~10GB)

1. Install a JDK 17 (e.g. Eclipse Temurin, a few hundred MB) and the
   **Android SDK command-line tools** only (not full Studio) from
   developer.android.com/studio → scroll to "Command line tools only."
2. Run its `sdkmanager` to install just `platform-tools`,
   `build-tools;35.0.0`, and `platforms;android-35` — skip the emulator
   system images, which are most of Studio's disk footprint.
3. From the project folder, run `gradle wrapper` once (needs a system
   Gradle install, or use Option A's cloud build instead if you'd rather
   not install Gradle either) to generate the wrapper files, then
   `./gradlew assembleDebug`.
4. Enable USB debugging on your phone (Settings → About phone → tap Build
   number 7 times → Developer options → USB debugging), plug it in, and
   run `adb install -r app/build/outputs/apk/debug/app-debug.apk`.
5. Edit code in any lightweight editor (VS Code is ~300MB) — you're just
   editing text files either way.

### Whichever option you pick — these still apply

1. **Get the face-embedding model.** Download a MobileFaceNet `.tflite`
   file (search "mobilefacenet.tflite" — several MIT/Apache-licensed
   mirrors exist on GitHub/Kaggle) and drop it at:
   `app/src/main/assets/mobilefacenet.tflite`
   Until this file is present, the app still runs and shows the camera
   preview, but recognition is disabled (you'll see a note on screen).
2. **Run OmniRoute — on the phone itself, so your laptop can be off.**
   OmniRoute officially supports running directly on Android via Termux, no
   root needed:
   - Install [Termux](https://f-droid.org/packages/com.termux/) from
     F-Droid (the Play Store build is outdated and blocked from updating).
   - In Termux: `pkg install nodejs -y && npm install -g omniroute && omniroute`
   - It starts serving on `http://localhost:20128` on the phone itself.
   - In the Aiowana app's Settings screen, set the base URL to
     `http://127.0.0.1:20128/v1` (already the default) — no laptop, no LAN
     IP needed, ever.
   - One real limitation, unavoidable for any hosted-model setup: the
     phone still needs its own internet connection (WiFi or mobile data)
     for OmniRoute to reach the actual free providers behind it (Groq,
     Cerebras, Gemini CLI's free tier, etc.) — a model itself isn't
     running on the phone, just the router. Face recognition has zero such
     requirement either way.
   - If you'd rather keep self-hosting on your PC instead (e.g. LAN-only,
     no internet needed on the phone once the assistant's model of choice
     is truly local via Ollama/llama.cpp), point the base URL at your PC's
     LAN IP as before — but then the PC does need to stay on.
3. **Install & run** on a physical phone (camera + mic behave more
   predictably than an emulator). Grant camera + microphone permissions
   when prompted.
4. **Enroll a face**: tap "Enroll Face," type a name, look at the camera,
   tap "Capture & Save." Repeat per person.
5. Tap **Talk** to speak to Aiowana; recognised faces get greeted
   automatically whenever they step in front of the camera.

### Option C — full Android Studio

Install Android Studio from developer.android.com/studio (free, ~10GB
with recommended components), open the `AiowanaAndroid` folder, let it
sync, then use the Run button as normal.

## Privacy, concretely

- Camera frames, face crops, and embeddings never leave the device — no
  network call happens anywhere in `FaceRecognizer.kt` or
  `FaceProfileStore.kt`.
- The **only** network call in the whole app is `OmniRouteClient.chat()`,
  and it sends just the recognised person's *name* (for personalisation)
  and whatever you said out loud — never a frame or embedding.
- Everything is stored in the app's private internal storage
  (`face_profiles.json`, SharedPreferences) — uninstalling the app deletes
  it all. There's no account, login, or cloud sync anywhere in this code.

## Known rough edges (this is a hackathon-speed Phase 1, not a finished app)

- `FaceRecognizer.MATCH_THRESHOLD` (0.62) is a starting guess — tune it
  against your own enrolled faces; too low = mixes people up, too high =
  never recognises anyone.
- Only the first face found in frame is used — fine for a personal
  assistant, not built for a room full of people.
- `compileSdk`/`targetSdk` are set to 35 (Android 15). Bump both to 36 in
  `app/build.gradle.kts` once your installed Android Studio/SDK supports
  it — nothing else in the code needs to change for that.
- `SpeechRecognizer` only recognises fully on-device on phones/Android
  versions that support it; otherwise it silently falls back to Google's
  (still free, but not local) recognizer service.
