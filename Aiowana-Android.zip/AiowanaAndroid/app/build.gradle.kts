plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aiowana.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aiowana.assistant"
        minSdk = 26          // CameraX + ML Kit floor
        targetSdk = 35       // bump to 36 in Android Studio once you have the newest SDK installed
        versionCode = 1
        versionName = "0.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
    // MobileFaceNet .tflite goes in src/main/assets — do NOT let AGP compress it
    androidResources {
        noCompress += "tflite"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Camera — local, on-device frame capture
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")

    // ML Kit Face Detection — runs fully on-device, free, no network call
    implementation("com.google.mlkit:face-detection:16.1.7")

    // TensorFlow Lite — runs the face-embedding model on-device
    implementation("org.tensorflow:tensorflow-lite:2.16.1")
    implementation("org.tensorflow:tensorflow-lite-support:0.4.4")

    // HTTP client for the OmniRoute call (the only network traffic in this app,
    // and only for the assistant's *replies* — never for face data)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Local, structured storage for enrolled face profiles (name + embedding)
    implementation("androidx.datastore:datastore-preferences:1.1.1")
}
