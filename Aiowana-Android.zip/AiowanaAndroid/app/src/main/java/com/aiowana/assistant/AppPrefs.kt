package com.aiowana.assistant

import android.content.Context

/** Plain local SharedPreferences — no cloud sync, nothing leaves the device. */
class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("aiowana_prefs", Context.MODE_PRIVATE)

    var baseUrl: String
        get() = prefs.getString("base_url", "http://127.0.0.1:20128/v1") ?: ""
        set(v) = prefs.edit().putString("base_url", v).apply()

    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) = prefs.edit().putString("api_key", v).apply()

    var model: String
        get() = prefs.getString("model", "hermes-3-llama-3.1-8b") ?: ""
        set(v) = prefs.edit().putString("model", v).apply()
}
