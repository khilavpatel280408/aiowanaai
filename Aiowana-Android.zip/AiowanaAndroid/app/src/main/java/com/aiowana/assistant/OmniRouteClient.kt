package com.aiowana.assistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * OmniRoute exposes an OpenAI-compatible /v1/chat/completions endpoint that
 * fans out to 1200+ models (including free-tier Hermes). This is the ONLY
 * network call this app makes — it carries the recognised person's name (for
 * a personalised system prompt) and the spoken text, nothing about the face
 * itself or the raw camera frame.
 *
 * Config (base URL / API key / model) is read from SettingsActivity's saved
 * preferences — see AppPrefs.kt. Defaults to http://127.0.0.1:20128/v1,
 * i.e. OmniRoute running on this same phone via Termux (see README) — so
 * the assistant's chat feature keeps working even if your PC is off. Point
 * it at a PC's LAN IP instead only if you're deliberately self-hosting
 * OmniRoute there.
 */
class OmniRouteClient(
    private val baseUrl: String,
    private val apiKey: String,
    private val model: String
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * [systemPrompt] carries the Aiowana persona + the recognised user's name
     * so replies can be personalised ("adaptive UI" at the conversation level).
     * Throws on network/parsing failure — caller decides how to surface that.
     */
    fun chat(systemPrompt: String, userMessage: String): String {
        val messages = JSONArray().apply {
            put(JSONObject().put("role", "system").put("content", systemPrompt))
            put(JSONObject().put("role", "user").put("content", userMessage))
        }
        val body = JSONObject().apply {
            put("model", model)
            put("messages", messages)
            put("temperature", 0.6)
        }

        val request = Request.Builder()
            .url("$baseUrl/chat/completions")
            .apply { if (apiKey.isNotBlank()) addHeader("Authorization", "Bearer $apiKey") }
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw RuntimeException("OmniRoute error ${response.code}: ${response.body?.string()}")
            }
            val json = JSONObject(response.body!!.string())
            return json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
                .trim()
        }
    }
}
