package com.aiowana.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.aiowana.assistant.databinding.ActivityMainBinding
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var faceRecognizer: FaceRecognizer
    private lateinit var voice: VoiceAssistant
    private lateinit var prefs: AppPrefs
    private val profileStore by lazy { FaceProfileStore(this) }
    private val cameraExecutor = Executors.newSingleThreadExecutor()

    // Adaptive-UI state: only greet / re-personalise when the recognised
    // person actually changes, not on every single frame.
    private var currentPerson: String? = null
    private var lastAnalysisMs = 0L

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted[Manifest.permission.CAMERA] == true) startCamera()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppPrefs(this)
        faceRecognizer = FaceRecognizer(this)
        voice = VoiceAssistant(this).also { it.init() }

        if (!faceRecognizer.modelReady) {
            binding.greetingText.text = getString(R.string.greeting_default) +
                "\n(mobilefacenet.tflite missing from assets — see README)"
        }

        binding.enrollButton.setOnClickListener {
            startActivity(Intent(this, EnrollFaceActivity::class.java))
        }
        binding.settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.micButton.setOnClickListener { onMicTapped() }

        requestPermissionsIfNeeded()
    }

    private fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) needed += Manifest.permission.CAMERA
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) needed += Manifest.permission.RECORD_AUDIO

        if (needed.isEmpty()) startCamera() else permissionLauncher.launch(needed.toTypedArray())
    }

    @androidx.camera.core.ExperimentalGetImage
    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }

            // Throttled: recognition doesn't need to run at full camera frame rate.
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { analysisUseCase ->
                    analysisUseCase.setAnalyzer(cameraExecutor) { imageProxy ->
                        val now = System.currentTimeMillis()
                        if (now - lastAnalysisMs < 800) {
                            imageProxy.close()
                        } else {
                            lastAnalysisMs = now
                            val profiles = profileStore.loadAll()
                            faceRecognizer.analyze(imageProxy, profiles) { name, _ ->
                                runOnUiThread { onFaceResult(name) }
                            }
                        }
                    }
                }

            provider.unbindAll()
            provider.bindToLifecycle(
                this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis
            )
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onFaceResult(name: String?) {
        if (name == currentPerson) return  // no change — don't re-greet every frame
        currentPerson = name
        if (name != null) {
            binding.greetingText.text = "Hey, $name!"
            voice.speak("Hey, $name!")
        } else {
            binding.greetingText.text = "I don't recognise this face yet."
        }
    }

    private fun onMicTapped() {
        binding.replyText.text = "Listening…"
        voice.listenOnce { heard ->
            if (heard.isNullOrBlank()) {
                binding.replyText.text = "Didn't catch that — try again."
                return@listenOnce
            }
            binding.replyText.text = "You: $heard"
            Thread {
                try {
                    val client = OmniRouteClient(prefs.baseUrl, prefs.apiKey, prefs.model)
                    val personName = currentPerson ?: "there"
                    val systemPrompt = "You are Aiowana, a concise and helpful personal AI " +
                        "assistant. The person talking to you right now is $personName. " +
                        "Keep replies short and natural, suitable to be read aloud."
                    val reply = client.chat(systemPrompt, heard)
                    runOnUiThread {
                        binding.replyText.text = reply
                        voice.speak(reply)
                    }
                } catch (e: Exception) {
                    runOnUiThread { binding.replyText.text = "OmniRoute error: ${e.message}" }
                }
            }.start()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        faceRecognizer.close()
        voice.release()
        cameraExecutor.shutdown()
    }
}
