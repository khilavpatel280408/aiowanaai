package com.aiowana.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Everything here lives in the app's private internal storage
 * (Context.filesDir) — never uploaded, never synced, never sent to
 * OmniRoute or anywhere else. Deleting the app deletes every face.
 */
data class FaceProfile(val name: String, val embedding: FloatArray)

class FaceProfileStore(context: Context) {

    private val file = File(context.filesDir, "face_profiles.json")

    fun loadAll(): List<FaceProfile> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                val embArr = obj.getJSONArray("embedding")
                val emb = FloatArray(embArr.length()) { embArr.getDouble(it).toFloat() }
                FaceProfile(obj.getString("name"), emb)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addProfile(profile: FaceProfile) {
        val current = loadAll().toMutableList()
        current.add(profile)
        saveAll(current)
    }

    fun removeProfile(name: String) {
        saveAll(loadAll().filterNot { it.name == name })
    }

    private fun saveAll(profiles: List<FaceProfile>) {
        val arr = JSONArray()
        profiles.forEach { p ->
            val obj = JSONObject()
            obj.put("name", p.name)
            val embArr = JSONArray()
            p.embedding.forEach { embArr.put(it.toDouble()) }
            obj.put("embedding", embArr)
            arr.put(obj)
        }
        file.writeText(arr.toString())
    }
}
