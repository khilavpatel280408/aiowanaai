package com.aiowana.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import androidx.camera.core.ImageProxy
import java.io.ByteArrayOutputStream
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.sqrt

/**
 * Two on-device models, nothing else:
 *  1) ML Kit Face Detection — finds/crops the face. Ships with Play Services,
 *     runs locally, no network call.
 *  2) MobileFaceNet (TFLite) — turns the cropped face into a 192-d vector.
 *     Put the .tflite file in app/src/main/assets/mobilefacenet.tflite
 *     (a free, open-weight model — see README for where to get it).
 *
 * Matching is plain cosine similarity against whatever is in FaceProfileStore.
 * No frame, crop, or embedding is ever written anywhere but this process's
 * memory and the local profile file.
 */
class FaceRecognizer(context: Context) {

    companion object {
        private const val MODEL_FILE = "mobilefacenet.tflite"
        private const val INPUT_SIZE = 112       // MobileFaceNet input is 112x112
        private const val EMBEDDING_SIZE = 192   // MobileFaceNet output length
        const val MATCH_THRESHOLD = 0.62f        // cosine similarity — tune after testing
    }

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .build()
    )

    private var interpreter: Interpreter? = try {
        val fd = context.assets.openFd(MODEL_FILE)
        val stream = fd.createInputStream()
        val buffer = stream.channel.map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        Interpreter(buffer)
    } catch (e: Exception) {
        null // model not dropped into assets yet — see README
    }

    val modelReady: Boolean get() = interpreter != null

    /**
     * Runs on a CameraX frame. Calls [onResult] with the matched profile name
     * (or null for "face seen but not recognised") on a background thread.
     * Calls it with `Pair(null, null)` if no face was found in the frame at all.
     */
    @androidx.camera.core.ExperimentalGetImage
    fun analyze(imageProxy: ImageProxy, profiles: List<FaceProfile>, onResult: (String?, Float?) -> Unit) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) { imageProxy.close(); return }

        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        detector.process(inputImage)
            .addOnSuccessListener { faces ->
                if (faces.isEmpty() || interpreter == null) {
                    onResult(null, null)
                } else {
                    val bitmap = yuv420ToBitmap(imageProxy)
                    val cropped = cropToFace(bitmap, faces[0], imageProxy.imageInfo.rotationDegrees)
                    val embedding = embed(cropped)
                    val (bestName, bestScore) = bestMatch(embedding, profiles)
                    onResult(bestName, bestScore)
                }
            }
            .addOnFailureListener { onResult(null, null) }
            .addOnCompleteListener { imageProxy.close() }
    }

    private fun bestMatch(embedding: FloatArray, profiles: List<FaceProfile>): Pair<String?, Float?> {
        var bestName: String? = null
        var bestScore = -1f
        profiles.forEach { p ->
            val score = cosineSimilarity(embedding, p.embedding)
            if (score > bestScore) { bestScore = score; bestName = p.name }
        }
        return if (bestScore >= MATCH_THRESHOLD) bestName to bestScore else null to bestScore
    }

    fun embedFromBitmap(bitmap: Bitmap): FloatArray = embed(bitmap)

    /** Used by EnrollFaceActivity: detect the face in a still bitmap and embed it. */
    fun detectAndEmbed(bitmap: Bitmap, onResult: (FloatArray?) -> Unit) {
        if (interpreter == null) { onResult(null); return }
        val inputImage = InputImage.fromBitmap(bitmap, 0)
        detector.process(inputImage)
            .addOnSuccessListener { faces ->
                if (faces.isEmpty()) onResult(null)
                else onResult(embed(cropToFace(bitmap, faces[0], 0)))
            }
            .addOnFailureListener { onResult(null) }
    }

    private fun embed(faceBitmap: Bitmap): FloatArray {
        val resized = Bitmap.createScaledBitmap(faceBitmap, INPUT_SIZE, INPUT_SIZE, true)
        val input = ByteBuffer.allocateDirect(4 * INPUT_SIZE * INPUT_SIZE * 3).apply {
            order(ByteOrder.nativeOrder())
        }
        for (y in 0 until INPUT_SIZE) {
            for (x in 0 until INPUT_SIZE) {
                val px = resized.getPixel(x, y)
                input.putFloat((((px shr 16) and 0xFF) - 127.5f) / 128f)
                input.putFloat((((px shr 8) and 0xFF) - 127.5f) / 128f)
                input.putFloat(((px and 0xFF) - 127.5f) / 128f)
            }
        }
        val output = Array(1) { FloatArray(EMBEDDING_SIZE) }
        interpreter?.run(input, output)
        return output[0]
    }

    /** CameraX hands us YUV_420_888 frames; ML Kit reads that format directly,
     *  but our own crop/resize step needs a Bitmap, so convert once here. */
    private fun yuv420ToBitmap(imageProxy: ImageProxy): Bitmap {
        val image = imageProxy.image!!
        val yBuffer = image.planes[0].buffer
        val uBuffer = image.planes[1].buffer
        val vBuffer = image.planes[2].buffer
        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()
        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)
        val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
        val out = ByteArrayOutputStream()
        yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), 90, out)
        val jpegBytes = out.toByteArray()
        return BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size)
    }

    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return -1f
        var dot = 0f; var na = 0f; var nb = 0f
        for (i in a.indices) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
        val denom = sqrt(na) * sqrt(nb)
        return if (denom == 0f) -1f else dot / denom
    }

    private fun cropToFace(bitmap: Bitmap, face: Face, rotationDegrees: Int): Bitmap {
        val box = face.boundingBox
        val safe = Rect(
            box.left.coerceAtLeast(0),
            box.top.coerceAtLeast(0),
            box.right.coerceAtMost(bitmap.width),
            box.bottom.coerceAtMost(bitmap.height)
        )
        val cropped = Bitmap.createBitmap(bitmap, safe.left, safe.top, safe.width(), safe.height())
        if (rotationDegrees == 0) return cropped
        val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
        return Bitmap.createBitmap(cropped, 0, 0, cropped.width, cropped.height, matrix, true)
    }

    fun close() {
        detector.close()
        interpreter?.close()
    }
}
