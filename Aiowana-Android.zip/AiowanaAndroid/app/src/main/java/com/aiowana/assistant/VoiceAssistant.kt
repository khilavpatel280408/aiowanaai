package com.aiowana.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Both pieces are built into Android — no API key, no cost, no server:
 *  - SpeechRecognizer: speech -> text. On recent Android versions with a
 *    supported device you can request on-device recognition
 *    (EXTRA_PREFER_OFFLINE) for full privacy; falls back to Google's
 *    recognizer service otherwise, which is still free but not local.
 *  - TextToSpeech: text -> speech, fully on-device.
 */
class VoiceAssistant(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null

    fun init(onReady: () -> Unit = {}) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                onReady()
            }
        }
    }

    fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aiowana_utt")
    }

    /** One-shot listen. Calls [onResult] with the heard text, or null on error/timeout. */
    fun listenOnce(onResult: (String?) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) { onResult(null); return }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle) {
                    val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    onResult(matches?.firstOrNull())
                }
                override fun onError(error: Int) = onResult(null)
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            // Ask for the on-device recognizer where the OS/device supports it —
            // keeps voice input local like the face pipeline. Silently ignored
            // on devices/versions that don't support it.
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        recognizer?.startListening(intent)
    }

    fun release() {
        tts?.shutdown()
        recognizer?.destroy()
    }
}
