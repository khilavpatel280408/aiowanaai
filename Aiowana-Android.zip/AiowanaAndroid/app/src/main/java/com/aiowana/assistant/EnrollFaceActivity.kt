package com.aiowana.assistant

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.core.Preview
import androidx.core.content.ContextCompat
import com.aiowana.assistant.databinding.ActivityEnrollFaceBinding
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

class EnrollFaceActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEnrollFaceBinding
    private lateinit var faceRecognizer: FaceRecognizer
    private val profileStore by lazy { FaceProfileStore(this) }
    private val cameraExecutor = Executors.newSingleThreadExecutor()

    @Volatile private var latestBitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEnrollFaceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        faceRecognizer = FaceRecognizer(this)
        startCamera()

        binding.captureButton.setOnClickListener { onCapture() }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.enrollPreview.surfaceProvider)
            }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor) { imageProxy ->
                        latestBitmap = yuvToBitmap(imageProxy)
                        imageProxy.close()
                    }
                }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onCapture() {
        val name = binding.nameInput.text.toString().trim()
        val bitmap = latestBitmap
        if (name.isEmpty()) { toast("Enter a name first"); return }
        if (bitmap == null) { toast("No frame yet — wait a second and try again"); return }

        faceRecognizer.detectAndEmbed(bitmap) { embedding ->
            runOnUiThread {
                if (embedding == null) {
                    toast("No face detected — face the camera and try again")
                } else {
                    profileStore.addProfile(FaceProfile(name, embedding))
                    toast("Saved $name")
                    finish()
                }
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun yuvToBitmap(imageProxy: androidx.camera.core.ImageProxy): Bitmap? {
        val image = imageProxy.image ?: return null
        val yBuffer = image.planes[0].buffer
        val uBuffer = image.planes[1].buffer
        val vBuffer = image.planes[2].buffer
        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()
        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)
        val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
        val out = ByteArrayOutputStream()
        yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), 90, out)
        val bytes = out.toByteArray()
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    override fun onDestroy() {
        super.onDestroy()
        faceRecognizer.close()
        cameraExecutor.shutdown()
    }
}
