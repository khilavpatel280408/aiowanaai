package com.aiowana.assistant

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.aiowana.assistant.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefs: AppPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = AppPrefs(this)

        binding.baseUrlInput.setText(prefs.baseUrl)
        binding.apiKeyInput.setText(prefs.apiKey)
        binding.modelInput.setText(prefs.model)

        binding.saveButton.setOnClickListener {
            prefs.baseUrl = binding.baseUrlInput.text.toString().trim().trimEnd('/')
            prefs.apiKey = binding.apiKeyInput.text.toString().trim()
            prefs.model = binding.modelInput.text.toString().trim()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
